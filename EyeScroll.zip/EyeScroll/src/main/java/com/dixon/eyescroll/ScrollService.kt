package com.dixon.eyescroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class ScrollService : AccessibilityService() {
    companion object { var instance: ScrollService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun swipe(next: Boolean) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val low = m.heightPixels * 0.75f
        val high = m.heightPixels * 0.25f
        val p = Path().apply {
            moveTo(x, if (next) low else high)
            lineTo(x, if (next) high else low)
        }
        val stroke = GestureDescription.StrokeDescription(p, 0, 200)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
