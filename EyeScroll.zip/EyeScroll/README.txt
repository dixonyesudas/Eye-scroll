EYESCROLL SETUP (Android Studio)
1. New Project > "Empty Views Activity", Kotlin, package: com.dixon.eyescroll, min SDK 26
2. Replace/copy these into the project:
   - src/main/AndroidManifest.xml  -> app/src/main/AndroidManifest.xml
   - src/main/res/xml + values     -> app/src/main/res/
   - the 3 .kt files               -> app/src/main/java/com/dixon/eyescroll/
   - add the dependencies from dependencies.txt to app/build.gradle(.kts)
3. Plug in phone (USB debugging) > Run.
4. In app: tap "Enable accessibility" > EyeScroll > turn on. Then "Start".
   (Android 13+: if greyed out, App info > 3 dots > Allow restricted settings)
5. Open Instagram reels. Long blink (~0.5-1s) = next. Left wink = previous.
Wink backwards? swap l and r in EyeService.kt. Tune timings there too.
