package com.dixon.eyescroll

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.SystemClock
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.*
import java.util.concurrent.Executors

class EyeService : LifecycleService() {
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .build()
    )
    private var closedAt = 0L
    private var winkAt = 0L
    private var cooldownUntil = 0L

    // tweak these
    private val blinkMin = 500L   // ms eyes closed to count as "next"
    private val winkMin = 400L    // ms left-eye wink for "previous"
    private val maxHold = 1500L

    override fun onCreate() {
        super.onCreate()
        val ch = "eyescroll"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "EyeScroll", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("EyeScroll is running")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { proxy ->
                val img = proxy.image
                if (img == null) { proxy.close(); return@setAnalyzer }
                detector.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
                    .addOnSuccessListener { faces ->
                        val f = faces.firstOrNull()
                        if (f != null) handle(f) else { closedAt = 0; winkAt = 0 }
                    }
                    .addOnCompleteListener { proxy.close() }
            }
            val provider = future.get()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handle(f: Face) {
        val l = f.leftEyeOpenProbability ?: return
        val r = f.rightEyeOpenProbability ?: return
        val now = SystemClock.uptimeMillis()

        val bothClosed = l < 0.3f && r < 0.3f
        val leftWink = l < 0.3f && r > 0.6f

        if (bothClosed) {
            if (closedAt == 0L) closedAt = now
        } else {
            if (closedAt != 0L && now - closedAt in blinkMin..maxHold) fire(true, now)
            closedAt = 0
        }

        if (leftWink) {
            if (winkAt == 0L) winkAt = now
        } else {
            if (winkAt != 0L && now - winkAt in winkMin..maxHold) fire(false, now)
            winkAt = 0
        }
    }

    private fun fire(next: Boolean, now: Long) {
        if (now < cooldownUntil) return
        cooldownUntil = now + 800
        ScrollService.instance?.swipe(next)
    }

    override fun onDestroy() { detector.close(); super.onDestroy() }
    override fun onBind(intent: Intent): android.os.IBinder? = super.onBind(intent)
}
